<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Sistema Ventas Laravel Vue Js - Dilia Soluciones, c.a.">
    <meta name="author" content="dilia.com.ve">
    <meta name="keyword" content="Sistema ventas Laravel Vue Js, Sistema compras Laravel Vue Js">
    <link rel="shortcut icon" href="img/favicon.png">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Sistema Ventas - Dilia Soluciones</title>
    <!-- Icons -->
    
    
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/template.css')); ?>" rel="stylesheet">
</head>

<body class="app header-fixed sidebar-fixed aside-menu-fixed aside-menu-hidden">
    <div id="app">
        <header class="app-header navbar">
            <button class="navbar-toggler mobile-sidebar-toggler d-lg-none mr-auto" type="button">
              <span class="navbar-toggler-icon"></span>
            </button>
            <a class="navbar-brand" href="#"></a>
            <button class="navbar-toggler sidebar-toggler d-md-down-none" type="button">
              <span class="navbar-toggler-icon"></span>
            </button>
            
            <ul class="nav navbar-nav ml-auto">
                <li class="nav-item d-md-down-none">
                    <a class="nav-link" href="#" data-toggle="dropdown">
                        <i class="icon-bell"></i>
                        <span class="badge badge-pill badge-danger">5</span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right">
                        <div class="dropdown-header text-center">
                            <strong>Notificaciones</strong>
                        </div>
                        <a class="dropdown-item" href="#">
                            <i class="fa fa-envelope-o"></i> Ingresos
                            <span class="badge badge-success">3</span>
                        </a>
                        <a class="dropdown-item" href="#">
                            <i class="fa fa-tasks"></i> Ventas
                            <span class="badge badge-danger">2</span>
                        </a>
                    </div>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle nav-link" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
                        <img src="img/avatars/6.png" class="img-avatar" alt="">
                        <span class="d-md-down-none"><?php echo e(Auth::user()->user); ?></span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right">
                        <div class="dropdown-header text-center">
                            <strong>Cuenta</strong>
                        </div>
                        
                        <a class="dropdown-item" href="<?php echo e(url('/logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit(); "><i class="fa fa-lock"></i> Cerrar sesión</a>
                        <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                            
                        </form>
                    </div>
                </li>
            </ul>
        </header>

        <div class="app-body">
            <?php if(Auth::check()): ?>
                <?php if(Auth::user()->role_id == 1): ?>
                    <?php echo $__env->make('layouts.adminsidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php elseif(Auth::user()->role_id == 2): ?>
                    <?php echo $__env->make('layouts.sellersidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php elseif(Auth::user()->role_id == 3): ?>
                    <?php echo $__env->make('layouts.storersidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>
            <?php endif; ?>
            
            <!-- Contenido Principal -->
           <?php echo $__env->yieldContent('content'); ?>
            <!-- /Fin del contenido principal -->
        </div>

    </div> <!-- /div id="app--> 
    

    <footer class="app-footer">
        <span><img src="img/dsl.png" width="30px" height="30px">&nbsp;&nbsp;Dilia Software</a> &copy; 2019</span>
        <span class="ml-auto">Desarrollado por <a href="http://www.dilia.com.ve/">Dilia Soluciones</a>&nbsp;&nbsp;<img src="img/logo.png" width="30px" height="20px"></span>
    </footer>

    <!-- Bootstrap and necessary plugins -->
    
    
    
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/template.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/Chart.min.js')); ?>" defer></script>
</body>

</html><?php /**PATH C:\xampp\htdocs\sale\resources\views/layouts/app2.blade.php ENDPATH**/ ?>